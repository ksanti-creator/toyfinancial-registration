import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import cookieSession from 'cookie-session';
import nodemailer from 'nodemailer';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'toyfinancial.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

app.use(express.json({ limit: '1mb' }));
app.use(cookieSession({
  name: 'toyfinancial_session',
  secret: process.env.SESSION_SECRET || 'development-only-change-me',
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 1000 * 60 * 60 * 12,
}));
app.use(express.static(path.join(__dirname, 'public')));

const products = ['ToyArmour', 'Toysurance', 'ToyProtection Plan'];
const statuses = ['New', 'Contacted', 'Qualified', 'Agreement Sent', 'Approved', 'Live', 'Closed Lost'];
const fulfillmentStatuses = ['Not requested', 'Requested', 'Picking', 'Shipped', 'Delivered'];

function now() { return new Date().toISOString(); }
function clean(value, max = 500) { return String(value || '').trim().slice(0, max); }
function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }
function isAdmin(req) { return Boolean(req.session?.adminId); }
function requireAdmin(req, res, next) { return isAdmin(req) ? next() : res.status(401).json({ error: 'Admin sign-in required.' }); }

function createSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS dealers (
      id INTEGER PRIMARY KEY, dealer_name TEXT NOT NULL, contact_name TEXT NOT NULL, title TEXT,
      email TEXT NOT NULL, phone TEXT NOT NULL, city TEXT NOT NULL, province TEXT NOT NULL, website TEXT,
      locations TEXT, products TEXT NOT NULL, categories TEXT, launch_timing TEXT, current_provider TEXT,
      value_notes TEXT, follow_up_method TEXT, meeting_interest TEXT, consent_at TEXT NOT NULL,
      lead_status TEXT NOT NULL DEFAULT 'New', assigned_to TEXT, last_contacted_at TEXT, notes TEXT,
      fulfillment_status TEXT NOT NULL DEFAULT 'Not requested', fulfillment_notes TEXT, created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY, product TEXT NOT NULL, province TEXT NOT NULL DEFAULT 'All', kind TEXT NOT NULL,
      title TEXT NOT NULL, url TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS outbox (
      id INTEGER PRIMARY KEY, recipient TEXT NOT NULL, subject TEXT NOT NULL, html TEXT NOT NULL,
      type TEXT NOT NULL, delivery_status TEXT NOT NULL, created_at TEXT NOT NULL
    );
  `);
  const adminEmail = clean(process.env.ADMIN_EMAIL || 'admin@toyfinancial.ca').toLowerCase();
  const existing = db.prepare('SELECT id FROM admins WHERE email = ?').get(adminEmail);
  if (!existing) db.prepare('INSERT INTO admins (email, password_hash, created_at) VALUES (?, ?, ?)')
    .run(adminEmail, bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'change-this-before-deploying', 12), now());
}
createSchema();

function getDocuments(selectedProducts, province) {
  const rows = db.prepare(`SELECT * FROM documents WHERE active = 1 AND product IN (${selectedProducts.map(() => '?').join(',')}) AND province IN ('All', ?) ORDER BY product, province DESC, kind, title`).all(...selectedProducts, province);
  return rows;
}
function productSections(selectedProducts, province) {
  const docs = getDocuments(selectedProducts, province);
  return selectedProducts.map(product => {
    const productDocs = docs.filter(doc => doc.product === product);
    const links = productDocs.length
      ? `<ul>${productDocs.map(doc => `<li><a href="${escapeHtml(doc.url)}">${escapeHtml(doc.title)}</a> <small>(${escapeHtml(doc.kind)})</small></li>`).join('')}</ul>`
      : `<p>Our partnerships team will send the ${escapeHtml(product)} materials shortly.</p>`;
    return `<section><h2>${escapeHtml(product)}</h2>${links}</section>`;
  }).join('');
}
function escapeHtml(value) { return String(value || '').replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c])); }
function emailTemplate(dealer) {
  const selected = JSON.parse(dealer.products);
  return `<!doctype html><html><body style="margin:0;background:#f2f3fb;font-family:Arial,sans-serif;color:#343a40"><div style="max-width:680px;margin:24px auto;background:#fff"><header style="padding:28px;background:#09253A;color:#fff"><strong style="font-size:24px;letter-spacing:.04em">TOYFINANCIAL</strong><p style="margin:8px 0 0;color:#b9def0">Dealer partnership starter pack</p></header><main style="padding:28px"><h1 style="color:#09253A">Thanks, ${escapeHtml(dealer.contact_name)}.</h1><p>We received ${escapeHtml(dealer.dealer_name)}’s request to explore ${selected.map(escapeHtml).join(', ')}. Here are the materials for your review.</p>${productSections(selected, dealer.province)}<hr><p><strong>What happens next:</strong> a ToyFinancial team member will follow up using your preferred method. This request does not constitute program approval or an executed dealer agreement.</p></main><footer style="padding:18px 28px;background:#09253A;color:#fff;font-size:12px">ToyFinancial Partnerships · Requested information only</footer></div></body></html>`;
}
function adminTemplate(dealer) {
  return `<h1>New ToyFinancial dealer registration</h1><p><strong>${escapeHtml(dealer.dealer_name)}</strong> · ${escapeHtml(dealer.city)}, ${escapeHtml(dealer.province)}</p><p>Contact: ${escapeHtml(dealer.contact_name)} (${escapeHtml(dealer.email)}, ${escapeHtml(dealer.phone)})</p><p>Programs: ${JSON.parse(dealer.products).map(escapeHtml).join(', ')}</p><p>Fulfillment: ${escapeHtml(dealer.fulfillment_status)}</p>`;
}
let transporter;
function mailer() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  if (!transporter) transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: Number(process.env.SMTP_PORT) === 465, auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
  return transporter;
}
async function sendOrQueue({ recipient, subject, html, type }) {
  const transport = mailer();
  let deliveryStatus = 'Queued (SMTP not configured)';
  if (transport) {
    await transport.sendMail({ from: process.env.SMTP_FROM || 'ToyFinancial Partnerships <partners@toyfinancial.ca>', to: recipient, subject, html });
    deliveryStatus = 'Sent';
  }
  db.prepare('INSERT INTO outbox (recipient, subject, html, type, delivery_status, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(recipient, subject, html, type, deliveryStatus, now());
}

app.post('/api/register', async (req, res, next) => {
  try {
    const b = req.body || {};
    const selectedProducts = Array.isArray(b.products) ? b.products.filter(p => products.includes(p)) : [];
    const required = ['dealerName', 'contactName', 'email', 'phone', 'city', 'province'];
    if (required.some(k => !clean(b[k])) || !validEmail(clean(b.email)) || !selectedProducts.length || b.consent !== true) {
      return res.status(400).json({ error: 'Please complete all required fields, select at least one program, and consent to follow-up.' });
    }
    const timestamp = now();
    const dealer = {
      dealer_name: clean(b.dealerName), contact_name: clean(b.contactName), title: clean(b.title), email: clean(b.email).toLowerCase(), phone: clean(b.phone), city: clean(b.city), province: clean(b.province), website: clean(b.website), locations: clean(b.locations), products: JSON.stringify(selectedProducts), categories: JSON.stringify(Array.isArray(b.categories) ? b.categories.map(x => clean(x, 100)) : []), launch_timing: clean(b.launchTiming), current_provider: clean(b.currentProvider), value_notes: clean(b.valueNotes, 2000), follow_up_method: clean(b.followUpMethod), meeting_interest: clean(b.meetingInterest), consent_at: timestamp, lead_status: 'New', assigned_to: '', last_contacted_at: '', notes: '', fulfillment_status: b.materialsRequested ? 'Requested' : 'Not requested', fulfillment_notes: clean(b.materialsNotes, 1000), created_at: timestamp, updated_at: timestamp,
    };
    const result = db.prepare(`INSERT INTO dealers (dealer_name, contact_name, title, email, phone, city, province, website, locations, products, categories, launch_timing, current_provider, value_notes, follow_up_method, meeting_interest, consent_at, lead_status, assigned_to, last_contacted_at, notes, fulfillment_status, fulfillment_notes, created_at, updated_at) VALUES (@dealer_name,@contact_name,@title,@email,@phone,@city,@province,@website,@locations,@products,@categories,@launch_timing,@current_provider,@value_notes,@follow_up_method,@meeting_interest,@consent_at,@lead_status,@assigned_to,@last_contacted_at,@notes,@fulfillment_status,@fulfillment_notes,@created_at,@updated_at)`).run(dealer);
    dealer.id = result.lastInsertRowid;
    await sendOrQueue({ recipient: dealer.email, subject: 'Your ToyFinancial dealer starter pack', html: emailTemplate(dealer), type: 'Dealer starter pack' });
    const admin = db.prepare('SELECT email FROM admins ORDER BY id LIMIT 1').get();
    if (admin) await sendOrQueue({ recipient: admin.email, subject: `New dealer registration: ${dealer.dealer_name}`, html: adminTemplate(dealer), type: 'Admin registration alert' });
    res.status(201).json({ ok: true, message: 'Registration received. Your tailored starter pack is on its way.' });
  } catch (error) { next(error); }
});

app.post('/api/admin/login', (req, res) => {
  const email = clean(req.body?.email).toLowerCase();
  const admin = db.prepare('SELECT * FROM admins WHERE email = ?').get(email);
  if (!admin || !bcrypt.compareSync(clean(req.body?.password), admin.password_hash)) return res.status(401).json({ error: 'Invalid email or password.' });
  req.session.adminId = admin.id; req.session.adminEmail = admin.email;
  res.json({ ok: true, email: admin.email });
});
app.post('/api/admin/logout', requireAdmin, (req, res) => { req.session = null; res.json({ ok: true }); });
app.get('/api/admin/session', (req, res) => res.json({ authenticated: isAdmin(req), email: req.session?.adminEmail || null }));
app.get('/api/admin/dealers', requireAdmin, (req, res) => {
  const search = clean(req.query.search, 100); const status = clean(req.query.status, 100);
  let sql = 'SELECT * FROM dealers WHERE 1=1'; const params = [];
  if (search) { sql += ' AND (dealer_name LIKE ? OR contact_name LIKE ? OR email LIKE ? OR city LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`); }
  if (statuses.includes(status)) { sql += ' AND lead_status = ?'; params.push(status); }
  sql += ' ORDER BY created_at DESC';
  res.json(db.prepare(sql).all(...params).map(formatDealer));
});
app.get('/api/admin/dealers/:id', requireAdmin, (req, res) => { const row = db.prepare('SELECT * FROM dealers WHERE id = ?').get(req.params.id); return row ? res.json(formatDealer(row)) : res.status(404).json({ error: 'Dealer not found.' }); });
function formatDealer(row) { return { ...row, products: JSON.parse(row.products || '[]'), categories: JSON.parse(row.categories || '[]') }; }
app.put('/api/admin/dealers/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM dealers WHERE id = ?').get(req.params.id); if (!existing) return res.status(404).json({ error: 'Dealer not found.' });
  const b = req.body || {}; const selectedProducts = Array.isArray(b.products) ? b.products.filter(p => products.includes(p)) : JSON.parse(existing.products);
  if (!clean(b.dealer_name || existing.dealer_name) || !validEmail(clean(b.email || existing.email)) || !selectedProducts.length) return res.status(400).json({ error: 'Dealer name, valid email, and a product selection are required.' });
  const fields = ['dealer_name','contact_name','title','email','phone','city','province','website','locations','launch_timing','current_provider','value_notes','follow_up_method','meeting_interest','lead_status','assigned_to','last_contacted_at','notes','fulfillment_status','fulfillment_notes'];
  const update = Object.fromEntries(fields.map(k => [k, clean(b[k] ?? existing[k], k.includes('notes') ? 2000 : 500)]));
  if (!statuses.includes(update.lead_status)) update.lead_status = existing.lead_status;
  if (!fulfillmentStatuses.includes(update.fulfillment_status)) update.fulfillment_status = existing.fulfillment_status;
  update.products = JSON.stringify(selectedProducts); update.categories = JSON.stringify(Array.isArray(b.categories) ? b.categories : JSON.parse(existing.categories || '[]')); update.updated_at = now(); update.id = existing.id;
  db.prepare(`UPDATE dealers SET dealer_name=@dealer_name,contact_name=@contact_name,title=@title,email=@email,phone=@phone,city=@city,province=@province,website=@website,locations=@locations,products=@products,categories=@categories,launch_timing=@launch_timing,current_provider=@current_provider,value_notes=@value_notes,follow_up_method=@follow_up_method,meeting_interest=@meeting_interest,lead_status=@lead_status,assigned_to=@assigned_to,last_contacted_at=@last_contacted_at,notes=@notes,fulfillment_status=@fulfillment_status,fulfillment_notes=@fulfillment_notes,updated_at=@updated_at WHERE id=@id`).run(update);
  res.json(formatDealer(db.prepare('SELECT * FROM dealers WHERE id = ?').get(existing.id)));
});
app.get('/api/admin/documents', requireAdmin, (req, res) => res.json(db.prepare('SELECT * FROM documents ORDER BY product, province, kind, title').all()));
app.post('/api/admin/documents', requireAdmin, (req, res) => {
  const b = req.body || {}; if (!products.includes(b.product) || !clean(b.title) || !/^https?:\/\//.test(clean(b.url)) || !clean(b.kind)) return res.status(400).json({ error: 'Product, title, document type, and a valid URL are required.' });
  const stamp = now(); const result = db.prepare('INSERT INTO documents (product,province,kind,title,url,active,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)').run(clean(b.product), clean(b.province || 'All'), clean(b.kind), clean(b.title), clean(b.url, 2000), b.active === false ? 0 : 1, stamp, stamp); res.status(201).json(db.prepare('SELECT * FROM documents WHERE id = ?').get(result.lastInsertRowid));
});
app.put('/api/admin/documents/:id', requireAdmin, (req, res) => { const b = req.body || {}; const row = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id); if (!row) return res.status(404).json({ error: 'Document not found.' }); if (!products.includes(b.product) || !clean(b.title) || !/^https?:\/\//.test(clean(b.url))) return res.status(400).json({ error: 'Valid product, title, and URL required.' }); db.prepare('UPDATE documents SET product=?,province=?,kind=?,title=?,url=?,active=?,updated_at=? WHERE id=?').run(clean(b.product),clean(b.province || 'All'),clean(b.kind),clean(b.title),clean(b.url,2000),b.active === false ? 0 : 1,now(),row.id); res.json(db.prepare('SELECT * FROM documents WHERE id=?').get(row.id)); });
app.delete('/api/admin/documents/:id', requireAdmin, (req, res) => { const result = db.prepare('DELETE FROM documents WHERE id = ?').run(req.params.id); res.status(result.changes ? 204 : 404).end(); });
app.get('/api/admin/outbox', requireAdmin, (req, res) => res.json(db.prepare('SELECT id,recipient,subject,type,delivery_status,created_at FROM outbox ORDER BY created_at DESC LIMIT 100').all()));
app.get('/api/admin/metrics', requireAdmin, (req, res) => { const count = value => db.prepare('SELECT COUNT(*) AS n FROM dealers WHERE ' + value).get().n; res.json({ total: count('1=1'), newLeads: count("lead_status = 'New'"), live: count("lead_status = 'Live'"), fulfillmentOpen: count("fulfillment_status IN ('Requested','Picking','Shipped')") }); });
app.use((_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.use((error, _, res, __) => { console.error(error); res.status(500).json({ error: 'Something went wrong. Please try again.' }); });
app.listen(PORT, () => console.log(`ToyFinancial registration app running on port ${PORT}`));
