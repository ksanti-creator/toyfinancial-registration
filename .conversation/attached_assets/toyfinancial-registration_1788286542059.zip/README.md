# ToyFinancial Dealer Registration

A Replit-ready dealer enrollment portal for **ToyArmour**, **Toysurance**, and **ToyProtection Plan**. It captures conference leads, emails a tailored starter pack, and gives administrators a practical dealer/fulfillment pipeline.

## What it does
- Mobile-first public registration flow; dealers may select any product combination.
- Product- and province-specific document links (starter guides, pricing sheets, certificates/contracts).
- One tailored acknowledgement email per registration, plus an internal alert.
- Secure admin portal: edit registrations, lead status/notes, physical-kit fulfillment, and document links.
- SQLite persistence—ideal for a single Replit deployment; use Replit persistent storage / a volume.
- In development without SMTP, every email is retained in **Admin → Outbox** instead of pretending it sent.

## Launch on Replit
1. Import this GitHub repository into Replit.
2. In **Secrets**, add `SESSION_SECRET`, `ADMIN_EMAIL`, and a strong `ADMIN_PASSWORD`.
3. Optional: add approved SMTP secrets (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`). Until then messages remain in the admin Outbox.
4. Click **Run**, then deploy. Configure a persistent disk/volume for `/home/runner/<repl>/data` before using it for live dealer records.
5. Visit `/admin` and sign in using the admin email/password. Add the approved Drive/marketing-document URLs per province in **Documents**.

## Important production steps
- Use an approved sender and confirm unsubscribe/consent wording with Marketing/Legal before mailing beyond the immediate requested material.
- Create actual dealer agreements in the approved system; this form is an interest/enrollment request, not program approval.
- Rotate the initial admin password and add SSO/role management if the portal becomes a company-wide system.
